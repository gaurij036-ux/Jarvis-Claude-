/**
 * Thin wrapper around window.speechSynthesis. Swap point: replace
 * the body of speak() with a call to ElevenLabs / Coqui TTS for a
 * production voice — callers only depend on this function's signature.
 */

export function isSpeechSynthesisSupported(): boolean {
  return "speechSynthesis" in window;
}

let preferredVoice: SpeechSynthesisVoice | null = null;

function pickVoice(): SpeechSynthesisVoice | null {
  if (preferredVoice) return preferredVoice;
  const voices = window.speechSynthesis.getVoices();
  // Mild preference for a clear en-US voice; falls back to whatever
  // the browser offers first.
  preferredVoice =
    voices.find((v) => v.lang === "en-US" && /male|en-US/i.test(v.name)) ??
    voices[0] ??
    null;
  return preferredVoice;
}

export function speak(text: string): Promise<void> {
  if (!isSpeechSynthesisSupported()) {
    console.warn("Speech synthesis not supported; skipping TTS for:", text);
    return Promise.resolve();
  }

  return new Promise((resolve) => {
    const utterance = new SpeechSynthesisUtterance(text);
    const voice = pickVoice();
    if (voice) utterance.voice = voice;
    utterance.rate = 1.02;
    utterance.pitch = 0.95;

    utterance.onend = () => resolve();
    utterance.onerror = () => resolve();

    window.speechSynthesis.cancel(); // don't stack overlapping replies
    window.speechSynthesis.speak(utterance);
  });
}

// Some browsers load voices asynchronously; refresh the cached pick
// once they're ready.
if (isSpeechSynthesisSupported()) {
  window.speechSynthesis.onvoiceschanged = () => {
    preferredVoice = null;
  };
}
