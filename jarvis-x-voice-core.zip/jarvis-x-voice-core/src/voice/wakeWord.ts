import { startContinuousRecognition, type RecognitionHandle } from "./speechRecognition";

const DEFAULT_WAKE_WORDS = ["jarvis"];

/**
 * Listens continuously and fires onWake whenever a wake word is
 * heard, passing along any trailing command spoken in the same
 * breath (e.g. "Jarvis, what's the weather" -> "what's the weather").
 * This lets users either say the wake word alone and wait, or say
 * the whole command in one go.
 */
export function startWakeWordListener(
  onWake: (trailingCommand: string) => void,
  onTranscript?: (transcript: string) => void,
  wakeWords: string[] = DEFAULT_WAKE_WORDS
): RecognitionHandle {
  return startContinuousRecognition((transcript) => {
    onTranscript?.(transcript);

    const lower = transcript.toLowerCase();
    const matched = wakeWords.find((w) => lower.includes(w));
    if (!matched) return;

    const idx = lower.indexOf(matched);
    const trailing = transcript
      .slice(idx + matched.length)
      .replace(/^[,.\s]+/, "")
      .trim();

    onWake(trailing);
  });
}
