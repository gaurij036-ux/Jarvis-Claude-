/**
 * Thin, typed wrapper around the browser's SpeechRecognition API
 * (Web Speech API). Chrome/Edge ship this as `webkitSpeechRecognition`.
 * Firefox and Safari support is inconsistent as of writing — this is
 * a browser-only prototype, not a cross-platform solution; the
 * production JARVIS-X app will likely swap this for a dedicated STT
 * provider (e.g. Whisper) behind the same interface.
 */

type SpeechRecognitionCtor = new () => SpeechRecognition;

function getRecognitionCtor(): SpeechRecognitionCtor | null {
  const w = window as any;
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function isSpeechRecognitionSupported(): boolean {
  return getRecognitionCtor() !== null;
}

export interface RecognitionHandle {
  stop: () => void;
}

/**
 * Starts continuous recognition and invokes onResult for every final
 * transcript chunk. Restarts itself automatically on "no-speech" /
 * network hiccups so a long-running wake-word listener doesn't die
 * silently — call stop() to end it deliberately.
 */
export function startContinuousRecognition(
  onResult: (transcript: string) => void,
  onError?: (error: string) => void
): RecognitionHandle {
  const Ctor = getRecognitionCtor();
  if (!Ctor) {
    throw new Error(
      "SpeechRecognition is not supported in this browser. Use Chrome or Edge."
    );
  }

  let stoppedDeliberately = false;
  let recognition = createInstance();

  function createInstance(): SpeechRecognition {
    const r = new Ctor!();
    r.continuous = true;
    r.interimResults = false;
    r.lang = "en-US";

    r.onresult = (event: SpeechRecognitionEvent) => {
      const last = event.results[event.results.length - 1];
      if (last.isFinal) {
        onResult(last[0].transcript.trim());
      }
    };

    r.onerror = (event: SpeechRecognitionErrorEvent) => {
      onError?.(event.error);
    };

    r.onend = () => {
      // Browsers stop recognition after a period of silence even in
      // continuous mode. Auto-restart unless we were told to stop.
      if (!stoppedDeliberately) {
        recognition = createInstance();
        recognition.start();
      }
    };

    return r;
  }

  recognition.start();

  return {
    stop: () => {
      stoppedDeliberately = true;
      recognition.stop();
    },
  };
}

/** Captures a single utterance and resolves with its transcript. */
export function listenOnce(timeoutMs = 8000): Promise<string> {
  const Ctor = getRecognitionCtor();
  if (!Ctor) {
    return Promise.reject(
      new Error("SpeechRecognition is not supported in this browser.")
    );
  }

  return new Promise((resolve, reject) => {
    const r = new Ctor();
    r.continuous = false;
    r.interimResults = false;
    r.lang = "en-US";

    const timer = setTimeout(() => {
      r.stop();
      reject(new Error("Listening timed out."));
    }, timeoutMs);

    r.onresult = (event: SpeechRecognitionEvent) => {
      clearTimeout(timer);
      resolve(event.results[0][0].transcript.trim());
    };

    r.onerror = (event: SpeechRecognitionErrorEvent) => {
      clearTimeout(timer);
      reject(new Error(event.error));
    };

    r.start();
  });
}
