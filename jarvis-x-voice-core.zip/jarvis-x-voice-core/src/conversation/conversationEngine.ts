import type { ConversationEngine, MemoryStore } from "../types";

/**
 * Mock "brain" for JARVIS-X. It's intentionally rule-based (no API
 * key required) so the voice loop is demoable out of the box.
 *
 * Swap point: this is where the AI Tool Integration Hub plugs in.
 * Replace getReply()'s body with a call to your provider of choice
 * (OpenRouter, OpenAI, Claude, Gemini, DeepSeek, or a local Ollama
 * model) and keep the same (userText, memory) -> string contract.
 * Everything upstream (wake word, STT, TTS, main.ts) stays unchanged.
 *
 * Example real implementation sketch:
 *
 *   const history = await memory.getChatHistory(10);
 *   const res = await fetch("http://localhost:11434/api/chat", {
 *     method: "POST",
 *     body: JSON.stringify({ model: "llama3", messages: [...history, { role: "user", content: userText }] }),
 *   });
 *   return (await res.json()).message.content;
 */
export class MockConversationEngine implements ConversationEngine {
  async getReply(userText: string, memory: MemoryStore): Promise<string> {
    const text = userText.toLowerCase().trim();
    const user = await memory.getUser();
    const name = user?.name ?? "there";

    if (!text) {
      return "I didn't catch a command. Go ahead, I'm listening.";
    }

    if (/\b(hello|hi|hey)\b/.test(text)) {
      return `Hello, ${name}. How can I help?`;
    }

    if (/what.*time/.test(text)) {
      const time = new Date().toLocaleTimeString();
      return `It's ${time}, ${name}.`;
    }

    if (/what.*(date|day)/.test(text)) {
      const date = new Date().toLocaleDateString(undefined, {
        weekday: "long",
        month: "long",
        day: "numeric",
      });
      return `Today is ${date}.`;
    }

    if (/remember (that )?/.test(text)) {
      const fact = text.replace(/remember (that )?/, "").trim();
      if (fact) {
        await memory.addMemory(fact, "fact");
        return `Noted. I'll remember that ${fact}.`;
      }
    }

    if (/what do you (remember|know) about me/.test(text)) {
      const memories = await memory.getMemories();
      if (memories.length === 0) {
        return "I don't have anything stored about you yet.";
      }
      const top = memories.slice(0, 3).map((m) => m.content).join("; ");
      return `Here's what I have: ${top}.`;
    }

    if (/forget (everything|it all|my memory)/.test(text)) {
      await memory.clearMemories();
      return "Done. I've cleared everything I remembered.";
    }

    if (/who are you/.test(text)) {
      return "I'm JARVIS-X, your assistant. Right now I'm running on a mock brain — swap in a real model whenever you're ready.";
    }

    // Default: acknowledge and log it as a learned "command" so the
    // future learning system has something to work from even in mock mode.
    await memory.addMemory(userText, "command");
    return `I heard: "${userText}". I don't have a real model connected yet, so I've just logged that command.`;
  }
}
