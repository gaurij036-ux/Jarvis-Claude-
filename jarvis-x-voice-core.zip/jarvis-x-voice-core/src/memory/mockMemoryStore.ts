import type {
  ChatMessage,
  MemoryEntry,
  MemoryStore,
  Preference,
  UserProfile,
} from "../types";

const STORAGE_KEY = "jarvis-x:mock-memory:v1";

interface MockMemoryShape {
  user: UserProfile | null;
  preferences: Preference[];
  memories: MemoryEntry[];
  chatHistory: ChatMessage[];
}

function emptyState(): MockMemoryShape {
  return { user: null, preferences: [], memories: [], chatHistory: [] };
}

function uid(): string {
  return crypto.randomUUID();
}

/**
 * Local, single-user stand-in for the future Supabase-backed memory
 * system. Persists to localStorage so "remember me across launches"
 * is demonstrable today, in a real browser, without a backend.
 *
 * Swap point: implement MemoryStore against Supabase (users,
 * user_preferences, memories, chat_history tables + RLS policies)
 * and pass that instance into ConversationEngine / main.ts instead
 * of this one. Nothing else in the app needs to change.
 */
export class MockMemoryStore implements MemoryStore {
  private state: MockMemoryShape;

  constructor() {
    this.state = this.load();
  }

  private load(): MockMemoryShape {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return emptyState();
      return JSON.parse(raw) as MockMemoryShape;
    } catch {
      return emptyState();
    }
  }

  private persist(): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
  }

  async getUser(): Promise<UserProfile | null> {
    return this.state.user;
  }

  async setUserName(name: string): Promise<UserProfile> {
    const profile: UserProfile = {
      id: this.state.user?.id ?? uid(),
      name,
      createdAt: this.state.user?.createdAt ?? new Date().toISOString(),
    };
    this.state.user = profile;
    this.persist();
    return profile;
  }

  async getPreferences(): Promise<Preference[]> {
    return this.state.preferences;
  }

  async setPreference(key: string, value: string): Promise<void> {
    const existing = this.state.preferences.find((p) => p.key === key);
    const updatedAt = new Date().toISOString();
    if (existing) {
      existing.value = value;
      existing.updatedAt = updatedAt;
    } else {
      this.state.preferences.push({ key, value, updatedAt });
    }
    this.persist();
  }

  async addMemory(
    content: string,
    tag: MemoryEntry["tag"]
  ): Promise<MemoryEntry> {
    const entry: MemoryEntry = {
      id: uid(),
      content,
      tag,
      createdAt: new Date().toISOString(),
    };
    this.state.memories.unshift(entry);
    this.state.memories = this.state.memories.slice(0, 200); // cap growth
    this.persist();
    return entry;
  }

  async getMemories(): Promise<MemoryEntry[]> {
    return this.state.memories;
  }

  async clearMemories(): Promise<void> {
    this.state.memories = [];
    this.persist();
  }

  async addChatMessage(
    role: ChatMessage["role"],
    content: string
  ): Promise<void> {
    const message: ChatMessage = {
      id: uid(),
      role,
      content,
      createdAt: new Date().toISOString(),
    };
    this.state.chatHistory.push(message);
    this.state.chatHistory = this.state.chatHistory.slice(-500);
    this.persist();
  }

  async getChatHistory(limit = 50): Promise<ChatMessage[]> {
    return this.state.chatHistory.slice(-limit);
  }

  /** Wipes everything — exposed for a future "forget me" UI action. */
  async resetAll(): Promise<void> {
    this.state = emptyState();
    this.persist();
  }
}
