/**
 * Shared types for JARVIS-X voice core.
 *
 * These shapes intentionally mirror the future Supabase tables
 * (see project README / roadmap: users, user_preferences, memories,
 * chat_history) so that swapping MockMemoryStore for a real
 * SupabaseMemoryStore later is a drop-in change, not a rewrite.
 */

export interface UserProfile {
  id: string;
  name: string | null;
  createdAt: string;
}

export interface Preference {
  key: string;
  value: string;
  updatedAt: string;
}

export interface MemoryEntry {
  id: string;
  content: string;
  tag: "command" | "interest" | "fact" | "habit";
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

export type AssistantState =
  | "idle"           // not listening at all
  | "wake-listening"  // continuously listening for the wake word
  | "active-listening" // heard the wake word, capturing a command
  | "thinking"        // command captured, generating a response
  | "speaking";        // speaking the response via TTS

/**
 * Contract every memory backend must satisfy. MockMemoryStore
 * implements this today; a SupabaseMemoryStore can implement it
 * later with zero changes to conversationEngine or main.ts.
 */
export interface MemoryStore {
  getUser(): Promise<UserProfile | null>;
  setUserName(name: string): Promise<UserProfile>;

  getPreferences(): Promise<Preference[]>;
  setPreference(key: string, value: string): Promise<void>;

  addMemory(content: string, tag: MemoryEntry["tag"]): Promise<MemoryEntry>;
  getMemories(): Promise<MemoryEntry[]>;
  clearMemories(): Promise<void>;

  addChatMessage(role: ChatMessage["role"], content: string): Promise<void>;
  getChatHistory(limit?: number): Promise<ChatMessage[]>;
}

/**
 * Contract every conversation "brain" must satisfy. Today this is a
 * small rule-based responder; the AI Tool Integration Hub milestone
 * replaces getReply() with a call to OpenRouter/OpenAI/Claude/Ollama/etc.
 * without touching the voice loop.
 */
export interface ConversationEngine {
  getReply(userText: string, memory: MemoryStore): Promise<string>;
}
