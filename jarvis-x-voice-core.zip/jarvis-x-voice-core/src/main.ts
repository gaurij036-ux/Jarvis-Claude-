import "./styles.css";
import { MockMemoryStore } from "./memory/mockMemoryStore";
import { MockConversationEngine } from "./conversation/conversationEngine";
import { startWakeWordListener } from "./voice/wakeWord";
import {
  listenOnce,
  isSpeechRecognitionSupported,
  type RecognitionHandle,
} from "./voice/speechRecognition";
import { speak, isSpeechSynthesisSupported } from "./voice/textToSpeech";
import type { AssistantState } from "./types";

const memory = new MockMemoryStore();
const engine = new MockConversationEngine();

const coreEl = document.getElementById("core")!;
const stateLabelEl = document.getElementById("stateLabel")!;
const micToggleEl = document.getElementById("micToggle") as HTMLButtonElement;
const greetingEl = document.getElementById("greeting")!;
const logEl = document.getElementById("log")!;

let wakeHandle: RecognitionHandle | null = null;
let isRunning = false;

function setState(state: AssistantState): void {
  coreEl.setAttribute("data-state", state);
  stateLabelEl.textContent = state.replace("-", " ").toUpperCase();
}

function logMessage(role: "user" | "assistant", content: string): void {
  const entry = document.createElement("div");
  entry.className = `log-entry ${role}`;
  const roleLabel = document.createElement("span");
  roleLabel.className = "role";
  roleLabel.textContent = role === "user" ? "YOU" : "JARVIS-X";
  const body = document.createElement("div");
  body.textContent = content;
  entry.append(roleLabel, body);
  logEl.append(entry);
  logEl.scrollTop = logEl.scrollHeight;
}

async function speakAndLog(text: string): Promise<void> {
  logMessage("assistant", text);
  setState("speaking");
  await memory.addChatMessage("assistant", text);
  await speak(text);
}

/** Handles a full command turn: transcribe -> think -> reply -> speak. */
async function handleCommand(trailingCommand: string): Promise<void> {
  setState("active-listening");

  let commandText = trailingCommand;
  if (!commandText) {
    // User just said the wake word alone — capture the next utterance.
    try {
      commandText = await listenOnce(6000);
    } catch {
      await speakAndLog("I didn't catch that. Try again whenever you're ready.");
      setState("wake-listening");
      return;
    }
  }

  logMessage("user", commandText);
  await memory.addChatMessage("user", commandText);

  setState("thinking");
  const reply = await engine.getReply(commandText, memory);

  await speakAndLog(reply);
  setState("wake-listening");
}

async function ensureUserName(): Promise<string> {
  const existing = await memory.getUser();
  if (existing?.name) return existing.name;

  await speak("What should I call you?");
  const name =
    window.prompt("What should I call you?")?.trim() || "there";
  await memory.setUserName(name);
  return name;
}

async function bootGreeting(): Promise<void> {
  const name = await ensureUserName();
  const history = await memory.getChatHistory(1);
  const isReturningUser = history.length > 0;

  const greeting = isReturningUser
    ? `Good to see you again, ${name}. Welcome back.`
    : `Nice to meet you, ${name}. I'm JARVIS-X, running in mock mode with local memory only.`;

  greetingEl.textContent = greeting;
  await speakAndLog(greeting);
  setState("idle");
}

function startListening(): void {
  if (isRunning) return;
  isRunning = true;
  micToggleEl.textContent = "Stop listening";
  micToggleEl.dataset.active = "true";
  setState("wake-listening");

  wakeHandle = startWakeWordListener(
    (trailing) => {
      handleCommand(trailing).catch((err) => {
        console.error(err);
        setState("wake-listening");
      });
    },
    (transcript) => {
      // Optional: surface raw transcripts for debugging/demo purposes.
      console.debug("[heard]", transcript);
    }
  );
}

function stopListening(): void {
  if (!isRunning) return;
  isRunning = false;
  wakeHandle?.stop();
  wakeHandle = null;
  micToggleEl.textContent = "Start listening";
  micToggleEl.dataset.active = "false";
  setState("idle");
}

micToggleEl.addEventListener("click", () => {
  if (isRunning) stopListening();
  else startListening();
});

async function init(): Promise<void> {
  if (!isSpeechRecognitionSupported() || !isSpeechSynthesisSupported()) {
    greetingEl.textContent =
      "This browser doesn't support the Web Speech API. Use desktop Chrome or Edge.";
    micToggleEl.disabled = true;
    return;
  }
  await bootGreeting();
}

init();
